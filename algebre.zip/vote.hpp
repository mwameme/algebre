#pragma once
#include <vector>
#include "TVD.hpp"

std::vector<double> vote(std::vector<std::vector<int>> const& votes, double epsilon);

std::vector<double> vote_iter(std::vector<std::vector<int>> const& votes, double epsilon,std::vector<double> const& poids);

std::vector<double> vote_n_iter(std::vector<std::vector<int>> const& votes, double epsilon,int iter);