#pragma once
#include <vector>
#include <iostream>
#include "polynome.hpp"
#include "rationnel.hpp"
#include "composition.hpp"
#include "types.hpp"
#include "composition.hpp"
#include "fact_for.hpp"

#include "norme.hpp"

//#include <typeinfo> 

template<typename T> class polynome;
template<typename T,class enable=void> class rationnel;

template<class T, class enable1 = void, class enable2=void> class matrice;

// matrice:
//cas type=1 ou 2 (static_assert)
//cas type=0, approx =1 ou 0
// 
//rationnel : cas type=1 ou 2
// 
//diagonalisation : cas approx=0 ou 1. Static_assert type=0
//

template<class T> class matrice<T,typename std::enable_if_t<type_algebre<T>::type==2>,void> {
public:

	friend matrice<T> derivee(const matrice<T>& element) {
		matrice<T> result(element);
		for (int i(0); i < element.taille; ++i)
			for (int j(0); j < element.taille; ++j)
				result.coeffs[i][j] = derivee(result.coeffs[i][j]);
		return result;
	};

	explicit matrice(int m_taille, T element) : coeffs(m_taille, std::vector<T>(m_taille, element)), taille(m_taille) {
	};

	explicit matrice(int m_taille) : coeffs(m_taille, std::vector<T>(m_taille)), taille(m_taille) { //d�conseill� � l'utilisation, sauf si vous savez ce que vous faites.
	};

	matrice(matrice<T> const& copie) {
		taille = copie.taille;
		coeffs = copie.coeffs;
	};

	explicit matrice(const std::vector<std::vector<T>>& vec) : coeffs(vec), taille(vec.size()) {
	};

	explicit matrice() : taille(0), coeffs(0, std::vector<T>(0)) {};

	explicit operator bool() const {
		for (int i(0); i < taille; ++i)
			for (int j(0); j < taille; ++j)
				if ((bool)coeffs[i][j])
					return true;
		return false;
	};

	template<class U> explicit operator matrice<U>() const {
		matrice<U> result;
		result.taille = taille;
		result.coeffs.resize(taille);
		for (int i(0); i < taille; ++i)
			result.coeffs[i].resize(taille);


		for (int i(0); i < taille; ++i)
			for (int j(0); j < taille; ++j)
				result.coeffs[i][j] = (U)coeffs[i][j];

		return result;
	};


	matrice<T>& operator=(bool test) {
		for (int i(0); i < taille; ++i)
			for (int j(0); j < taille; ++j)
				coeffs[i][j] = false;
		if (test)
			for (int i(0); i < taille; ++i)
				coeffs[i][i] = true;
		return *this;

	};

	template<class U> friend matrice<T> operator*(U scalaire, const matrice<T>& m_matrice) {
		matrice<T> result(m_matrice);
		for (int i(0); i < result.taille; ++i)
			for (int j(0); j < result.taille; ++j)
				result.coeffs[i][j] = scalaire * result.coeffs[i][j];
		return result;
	};

	/*
	friend matrice<T> operator%(const matrice<T>& temp1, const matrice<T>& temp2) {
		matrice<T> result = temp1;
		result = false;
		return result;
	};
	*/

	matrice<T> operator*(const matrice<T>& autre) const {
		T faux = coeffs[0][0];
		faux = false;

		if (taille != autre.taille)
			return matrice<T>(taille, faux);
		matrice<T> result(taille, faux);
		for (int i(0); i < taille; ++i)
			for (int j(0); j < taille; ++j) {
				T somme(faux);
				for (int k(0); k < taille; ++k)
					somme = somme + (coeffs[i][k] * autre.coeffs[k][j]);
				result.coeffs[i][j] = somme;
			}
		return result;
	};

	matrice<T> operator+(const matrice<T>& autre) const {
		T faux = coeffs[0][0];
		faux = false;

		if (taille != autre.taille)
			return matrice<T>(taille, faux);
		matrice<T> result(taille, faux);
		for (int i(0); i < taille; ++i)
			for (int j(0); j < taille; ++j)
				result.coeffs[i][j] = coeffs[i][j] + autre.coeffs[i][j];
		return result;
	};

	matrice<T> operator-(const matrice<T>& autre) const {
		T faux = coeffs[0][0];
		faux = false;
		if (taille != autre.taille)
			return matrice<T>(taille, faux);

		matrice<T> result(taille, faux);
		for (int i(0); i < taille; ++i)
			for (int j(0); j < taille; ++j)
				result.coeffs[i][j] = coeffs[i][j] - autre.coeffs[i][j];
		return result;
	};

	friend 	matrice<T> operator-(const matrice<T>& element) {
		T temp = element.coeffs[0][0];
		temp = false;
		matrice<T> result(element.taille, temp);
		for (int i(0); i < result.taille; ++i)
			for (int j(0); j < result.taille; ++j)
				result.coeffs[i][j] = -element.coeffs[i][j];
		return result;
	};
	
	T determinant_anneau() {
		T resultat = coeffs[0][0];
		resultat = false;
		T vrai = resultat;
		vrai = true;
		for (fact_for iter(taille); (bool)iter; ++iter) {
			T temp = vrai;
			for (int i(0); i < taille; ++i)
				temp = temp * coeffs[i][iter.permutation[i]];
			temp = iter.signature * temp;
			resultat = resultat + temp;
		}

		return resultat;
	};
	
	inline T determinant() const {
		return determinant_anneau();
	};


	void echangerLigne(int i, int j) {
		if ((i < 0) || (i >= taille) || (j < 0) || (j >= taille))
			return;
		if (i == j)
			return;
		for (int k(0); k < taille; ++k) {
			T temp = coeffs[i][k];
			coeffs[i][k] = coeffs[j][k];
			coeffs[j][k] = temp;
		}
		return;
	};

	void ajouterLigne(int i, int j, T coefficient) { // ajouter ligne i * coeffs � la ligne j ...
		if ((i < 0) || (i >= taille) || (j < 0) || (j >= taille))
			return;
		if (i == j)
			return;
		for (int k(0); k < taille; ++k) {
			coeffs[j][k] = coeffs[j][k] + (coefficient * coeffs[i][k]);
		}
		return;
	};

	void multiplierLigne(int i, T coefficient) {
		for (int j(0); j < taille; ++j)
			coeffs[i][j] = coefficient * coeffs[i][j];
	};

	polynome<T> polynomeCaracteristique() const {
		T faux = coeffs[0][0];
		faux = false;

		T vrai = faux;
		vrai = true;

		T mvrai = vrai;
		mvrai = -mvrai;

		polynome<T> m_poly = polynome<T>(vrai);

		matrice<polynome<T>> m_matrice(taille, m_poly);

		for (int i(0); i < taille; ++i)
			for (int j(0); j < taille; ++j)
				if (i != j)
					m_matrice.coeffs[i][j] = polynome<T>(coeffs[i][j]);
				else
					m_matrice.coeffs[i][j] = polynome<T>(std::vector<T>{ coeffs[i][j], mvrai });

		polynome<T> det = m_matrice.determinant();

		return det;
	};


	friend std::ostream& operator<<(std::ostream& os, const matrice<T>& element) {
		os << "{ ";
		for (int i(0); i < element.taille; ++i) {
			os << "{ ";
			for (int j(0); j < element.taille - 1; ++j)
				os << element.coeffs[i][j] << " , ";
			if (i < element.taille - 1)
				os << element.coeffs[i][element.taille - 1] << " } ,";
			else
				os << element.coeffs[i][element.taille - 1] << " }";

			if (i < element.taille - 1)
				os << std::endl;
		}
		os << "}" << std::endl;
		return os;
	};


	friend std::vector<T> operator*(std::vector<T> const& vec_ligne, matrice<T> const& m_matrice) {
		T faux = m_matrice.coeffs[0][0];
		faux = false;
		std::vector<T> resultat(m_matrice.taille, faux);
		for (int i(0); i < m_matrice.taille; ++i) {
			T somme = faux;
			for (int j(0); j < m_matrice.taille; ++j)
				somme = somme + (vec_ligne[j] * m_matrice.coeffs[j][i]);
			resultat[i] = somme;
		}

		return resultat;
	};

	friend std::vector<T> operator*(matrice<T> const& m_matrice, std::vector<T> const& vec_colonne) {
		T faux = m_matrice.coeffs[0][0];
		faux = false;
		std::vector<T> resultat(m_matrice.taille, faux);
		for (int i(0); i < m_matrice.taille; ++i) {
			T somme = faux;
			for (int j(0); j < m_matrice.taille; ++j)
				somme = somme + (m_matrice.coeffs[i][j] * vec_colonne[j]);
			resultat[i] = somme;
		}
		return resultat;
	};

	int taille;
	std::vector < std::vector< T>> coeffs;
};


template<class T> class matrice<T, typename std::enable_if_t<type_algebre<T>::type == 1>, void> {
public:

	friend matrice<T> derivee(const matrice<T>& element) {
		matrice<T> result(element);
		for (int i(0); i < element.taille; ++i)
			for (int j(0); j < element.taille; ++j)
				result.coeffs[i][j] = derivee(result.coeffs[i][j]);
		return result;
	};

	explicit matrice(int m_taille, T element) : coeffs(m_taille, std::vector<T>(m_taille, element)), taille(m_taille) {
	};

	explicit matrice(int m_taille) : coeffs(m_taille, std::vector<T>(m_taille)), taille(m_taille) {
	};

	matrice(matrice<T> const& copie) {
		taille = copie.taille;
		coeffs = copie.coeffs;
	};

	explicit matrice(const std::vector<std::vector<T>>& vec) : coeffs(vec), taille(vec.size()) {
	};

	explicit matrice() : taille(0), coeffs(0, std::vector<T>(0)) {};

	explicit operator bool() const {
		for (int i(0); i < taille; ++i)
			for (int j(0); j < taille; ++j)
				if ((bool)coeffs[i][j])
					return true;
		return false;
	};

	template<class U> explicit operator matrice<U>() const {
		matrice<U> result;
		result.taille = taille;
		result.coeffs.resize(taille);
		for (int i(0); i < taille; ++i)
			result.coeffs[i].resize(taille);


		for (int i(0); i < taille; ++i)
			for (int j(0); j < taille; ++j)
				result.coeffs[i][j] = (U)coeffs[i][j];

		return result;
	};


	matrice<T>& operator=(bool test) {
		for (int i(0); i < taille; ++i)
			for (int j(0); j < taille; ++j)
				coeffs[i][j] = false;
		if (test)
			for (int i(0); i < taille; ++i)
				coeffs[i][i] = true;
		return *this;

	};

	template<class U> friend matrice<T> operator*(U scalaire, const matrice<T>& m_matrice) {
		matrice<T> result(m_matrice);
		for (int i(0); i < result.taille; ++i)
			for (int j(0); j < result.taille; ++j)
				result.coeffs[i][j] = scalaire * result.coeffs[i][j];
		return result;
	};

	/*
	friend matrice<T> operator%(const matrice<T>& temp1, const matrice<T>& temp2) {
		matrice<T> result = temp1;
		result = false;
		return result;
	};
	*/

	matrice<T> operator*(const matrice<T>& autre) const {
		T faux = coeffs[0][0];
		faux = false;

		if (taille != autre.taille)
			return matrice<T>(taille, faux);
		matrice<T> result(taille, faux);
		for (int i(0); i < taille; ++i)
			for (int j(0); j < taille; ++j) {
				T somme(faux);
				for (int k(0); k < taille; ++k)
					somme = somme + (coeffs[i][k] * autre.coeffs[k][j]);
				result.coeffs[i][j] = somme;
			}
		return result;
	};

	matrice<T> operator+(const matrice<T>& autre) const {
		T faux = coeffs[0][0];
		faux = false;

		if (taille != autre.taille)
			return matrice<T>(taille, faux);
		matrice<T> result(taille, faux);
		for (int i(0); i < taille; ++i)
			for (int j(0); j < taille; ++j)
				result.coeffs[i][j] = coeffs[i][j] + autre.coeffs[i][j];
		return result;
	};

	matrice<T> operator-(const matrice<T>& autre) const {
		T faux = coeffs[0][0];
		faux = false;
		if (taille != autre.taille)
			return matrice<T>(taille, faux);

		matrice<T> result(taille, faux);
		for (int i(0); i < taille; ++i)
			for (int j(0); j < taille; ++j)
				result.coeffs[i][j] = coeffs[i][j] - autre.coeffs[i][j];
		return result;
	};

	friend 	matrice<T> operator-(const matrice<T>& element) {
		T temp = element.coeffs[0][0];
		temp = false;
		matrice<T> result(element.taille, temp);
		for (int i(0); i < result.taille; ++i)
			for (int j(0); j < result.taille; ++j)
				result.coeffs[i][j] = -element.coeffs[i][j];
		return result;
	};

	T determinant_anneau() {
		T resultat = coeffs[0][0];
		resultat = false;
		T vrai = resultat;
		vrai = true;
		for (fact_for iter(taille); (bool)iter; ++iter) {
			T temp = vrai;
			for (int i(0); i < taille; ++i)
				temp = temp * coeffs[i][iter.permutation[i]];
			temp = iter.signature * temp;
			resultat = resultat + temp;
		}

		return resultat;
	};

	
	T determinant() const {
		matrice<rationnel<T>> m_matrice(taille);
		T vrai = coeffs[0][0];
		vrai = true;
		for (int i(0); i < taille; ++i)
			for (int j(0); j < taille; ++j)
				m_matrice.coeffs[i][j] = rationnel<T>(coeffs[i][j], vrai);

		rationnel<T> det = m_matrice.determinant();

		return det.numerateur / det.denominateur;
	};

	void echangerLigne(int i, int j) {
		if ((i < 0) || (i >= taille) || (j < 0) || (j >= taille))
			return;
		if (i == j)
			return;
		for (int k(0); k < taille; ++k) {
			T temp = coeffs[i][k];
			coeffs[i][k] = coeffs[j][k];
			coeffs[j][k] = temp;
		}
		return;
	};

	void ajouterLigne(int i, int j, T coefficient) { // ajouter ligne i * coeffs � la ligne j ...
		if ((i < 0) || (i >= taille) || (j < 0) || (j >= taille))
			return;
		if (i == j)
			return;
		for (int k(0); k < taille; ++k) {
			coeffs[j][k] = coeffs[j][k] + (coefficient * coeffs[i][k]);
		}
		return;
	};

	void multiplierLigne(int i, T coefficient) {
		for (int j(0); j < taille; ++j)
			coeffs[i][j] = coefficient * coeffs[i][j];
	};

	polynome<T> polynomeCaracteristique() const {
		T faux = coeffs[0][0];
		faux = false;

		T vrai = faux;
		vrai = true;

		T mvrai = vrai;
		mvrai = -mvrai;

		polynome<T> m_poly = polynome<T>(vrai);

		matrice<polynome<T>> m_matrice(taille, m_poly);

		for (int i(0); i < taille; ++i)
			for (int j(0); j < taille; ++j)
				if (i != j)
					m_matrice.coeffs[i][j] = polynome<T>(coeffs[i][j]);
				else
					m_matrice.coeffs[i][j] = polynome<T>(std::vector<T>{ coeffs[i][j], mvrai });

		polynome<T> det = m_matrice.determinant();

		return det;
	};


	friend std::ostream& operator<<(std::ostream& os, const matrice<T>& element) {
		os << "{ ";
		for (int i(0); i < element.taille; ++i) {
			os << "{ ";
			for (int j(0); j < element.taille - 1; ++j)
				os << element.coeffs[i][j] << " , ";
			if (i < element.taille - 1)
				os << element.coeffs[i][element.taille - 1] << " } ,";
			else
				os << element.coeffs[i][element.taille - 1] << " }";

			if (i < element.taille - 1)
				os << std::endl;
		}
		os << "}" << std::endl;
		return os;
	};


	friend std::vector<T> operator*(std::vector<T> const& vec_ligne, matrice<T> const& m_matrice) {
		T faux = m_matrice.coeffs[0][0];
		faux = false;
		std::vector<T> resultat(m_matrice.taille, faux);
		for (int i(0); i < m_matrice.taille; ++i) {
			T somme = faux;
			for (int j(0); j < m_matrice.taille; ++j)
				somme = somme + (vec_ligne[j] * m_matrice.coeffs[j][i]);
			resultat[i] = somme;
		}

		return resultat;
	};

	friend std::vector<T> operator*(matrice<T> const& m_matrice, std::vector<T> const& vec_colonne) {
		T faux = m_matrice.coeffs[0][0];
		faux = false;
		std::vector<T> resultat(m_matrice.taille, faux);
		for (int i(0); i < m_matrice.taille; ++i) {
			T somme = faux;
			for (int j(0); j < m_matrice.taille; ++j)
				somme = somme + (m_matrice.coeffs[i][j] * vec_colonne[j]);
			resultat[i] = somme;
		}
		return resultat;
	};

	int taille;
	std::vector < std::vector< T>> coeffs;
};


template<class T> class matrice<T, typename std::enable_if_t<type_algebre<T>::type == 0>, typename std::enable_if_t<type_algebre<T>::approx==0>> {
public:

	friend matrice<T> derivee(const matrice<T>& element) {
		matrice<T> result(element);
		for (int i(0); i < element.taille; ++i)
			for (int j(0); j < element.taille; ++j)
				result.coeffs[i][j] = derivee(result.coeffs[i][j]);
		return result;
	};

	explicit matrice(int m_taille, T element) : coeffs(m_taille, std::vector<T>(m_taille, element)), taille(m_taille) {
	};

	explicit matrice(int m_taille) : coeffs(m_taille, std::vector<T>(m_taille)), taille(m_taille) {
	};

	matrice(matrice<T> const& copie) {
		taille = copie.taille;
		coeffs = copie.coeffs;
	};

	explicit matrice(const std::vector<std::vector<T>>& vec) : coeffs(vec), taille(vec.size()) {
	};

	explicit matrice() : taille(0), coeffs(0, std::vector<T>(0)) {};

	explicit operator bool() const {
		for (int i(0); i < taille; ++i)
			for (int j(0); j < taille; ++j)
				if ((bool)coeffs[i][j])
					return true;
		return false;
	};

	template<class U> explicit operator matrice<U>() const {
		matrice<U> result;
		result.taille = taille;
		result.coeffs.resize(taille);
		for (int i(0); i < taille; ++i)
			result.coeffs[i].resize(taille);


		for (int i(0); i < taille; ++i)
			for (int j(0); j < taille; ++j)
				result.coeffs[i][j] = (U)coeffs[i][j];

		return result;
	};


	matrice<T>& operator=(bool test) {
		for (int i(0); i < taille; ++i)
			for (int j(0); j < taille; ++j)
				coeffs[i][j] = false;
		if (test)
			for (int i(0); i < taille; ++i)
				coeffs[i][i] = true;
		return *this;

	};

	template<class U> friend matrice<T> operator*(U scalaire, const matrice<T>& m_matrice) {
		matrice<T> result(m_matrice);
		for (int i(0); i < result.taille; ++i)
			for (int j(0); j < result.taille; ++j)
				result.coeffs[i][j] = scalaire * result.coeffs[i][j];
		return result;
	};

	/*
	friend matrice<T> operator%(const matrice<T>& temp1, const matrice<T>& temp2) {
		matrice<T> result = temp1;
		result = false;
		return result;
	};
	*/

	matrice<T> operator*(const matrice<T>& autre) const {
		T faux = coeffs[0][0];
		faux = false;

		if (taille != autre.taille)
			return matrice<T>(taille, faux);
		matrice<T> result(taille, faux);
		for (int i(0); i < taille; ++i)
			for (int j(0); j < taille; ++j) {
				T somme(faux);
				for (int k(0); k < taille; ++k)
					somme = somme + (coeffs[i][k] * autre.coeffs[k][j]);
				result.coeffs[i][j] = somme;
			}
		return result;
	};

	matrice<T> operator+(const matrice<T>& autre) const {
		T faux = coeffs[0][0];
		faux = false;

		if (taille != autre.taille)
			return matrice<T>(taille, faux);
		matrice<T> result(taille, faux);
		for (int i(0); i < taille; ++i)
			for (int j(0); j < taille; ++j)
				result.coeffs[i][j] = coeffs[i][j] + autre.coeffs[i][j];
		return result;
	};

	matrice<T> operator-(const matrice<T>& autre) const {
		T faux = coeffs[0][0];
		faux = false;
		if (taille != autre.taille)
			return matrice<T>(taille, faux);

		matrice<T> result(taille, faux);
		for (int i(0); i < taille; ++i)
			for (int j(0); j < taille; ++j)
				result.coeffs[i][j] = coeffs[i][j] - autre.coeffs[i][j];
		return result;
	};

	friend 	matrice<T> operator-(const matrice<T>& element) {
		T temp = element.coeffs[0][0];
		temp = false;
		matrice<T> result(element.taille, temp);
		for (int i(0); i < result.taille; ++i)
			for (int j(0); j < result.taille; ++j)
				result.coeffs[i][j] = -element.coeffs[i][j];
		return result;
	};

	T determinant_anneau() {
		T resultat = coeffs[0][0];
		resultat = false;
		T vrai = resultat;
		vrai = true;
		for (fact_for iter(taille); (bool)iter; ++iter) {
			T temp = vrai;
			for (int i(0); i < taille; ++i)
				temp = temp * coeffs[i][iter.permutation[i]];
			temp = iter.signature * temp;
			resultat = resultat + temp;
		}

		return resultat;
	};

	T determinant() const {
		matrice<T> m_matrice(*this);
		T det(coeffs[0][0]);
		det = true;

		for (int i(0); i < taille; ++i) {
			int j;
			for (j = i; j < taille; ++j) {
				if ((bool)m_matrice.coeffs[i][j])
					break;
			}
			if (j == taille)
				return (det = false);

			if (i != j) {
				m_matrice.echangerLigne(i, j);
				det = -det;
			}
			for (j = i + 1; j < taille; ++j) {
				m_matrice.ajouterLigne(i, j, ((-m_matrice.coeffs[j][i]) / m_matrice.coeffs[i][i]));
			}

		}

		for (int i(0); i < taille; ++i)
			det = (det * m_matrice.coeffs[i][i]);

		return det;
	};


	void echangerLigne(int i, int j) {
		if ((i < 0) || (i >= taille) || (j < 0) || (j >= taille))
			return;
		if (i == j)
			return;
		for (int k(0); k < taille; ++k) {
			T temp = coeffs[i][k];
			coeffs[i][k] = coeffs[j][k];
			coeffs[j][k] = temp;
		}
		return;
	};

	void ajouterLigne(int i, int j, T coefficient) { // ajouter ligne i * coeffs � la ligne j ...
		if ((i < 0) || (i >= taille) || (j < 0) || (j >= taille))
			return;
		if (i == j)
			return;
		for (int k(0); k < taille; ++k) {
			coeffs[j][k] = coeffs[j][k] + (coefficient * coeffs[i][k]);
		}
		return;
	};

	void multiplierLigne(int i, T coefficient) {
		for (int j(0); j < taille; ++j)
			coeffs[i][j] = coefficient * coeffs[i][j];
	};

	matrice<T> inverse() const {
		T vrai = coeffs[0][0];
		vrai = true;

		matrice<T> m_matrice(*this);
		matrice<T> resultat(taille, vrai);
		resultat = true; //identit�

		for (int i(0); i < taille; ++i) {
			int j(i);
			for (j = i; j < taille; ++j)
				if ((bool)coeffs[i][j])
					break;
			if (j == taille)
				throw std::domain_error("matrice non-inversible");


			if (!((bool)coeffs[i][j])) {
				return (resultat = false);
			}
			if (i != j) {
				m_matrice.echangerLigne(i, j);
				resultat.echangerLigne(i, j);
			}
			resultat.multiplierLigne(i, vrai / m_matrice.coeffs[i][i]);
			m_matrice.multiplierLigne(i, vrai / m_matrice.coeffs[i][i]);

			for (j = 0; j < taille; ++j) {
				if (j == i)
					continue;
				resultat.ajouterLigne(i, j, -m_matrice.coeffs[j][i]);
				m_matrice.ajouterLigne(i, j, -m_matrice.coeffs[j][i]);
			}
		}

		return resultat;
	};

	polynome<T> polynomeCaracteristique() const {
		T faux = coeffs[0][0];
		faux = false;

		T vrai = faux;
		vrai = true;

		T mvrai = vrai;
		mvrai = -mvrai;

		matrice<polynome<T>> m_matrice(taille, polynome<T>(faux));

		for (int i(0); i < taille; ++i)
			for (int j(0); j < taille; ++j)
				if (i != j)
					m_matrice.coeffs[i][j] = polynome<T>(coeffs[i][j]);
				else
					m_matrice.coeffs[i][j] = polynome<T>(coeffs[i][j], mvrai);

		auto det = m_matrice.determinant();

		return det;
	};
	//si T est un anneau, calculer pour matrice<rationnel<T>> et simplifier les fractions de polynome<rationnel<T>>


	friend std::ostream& operator<<(std::ostream& os, const matrice<T>& element) {
		os << "{ ";
		for (int i(0); i < element.taille; ++i) {
			os << "{ ";
			for (int j(0); j < element.taille - 1; ++j)
				os << element.coeffs[i][j] << " , ";
			if (i < element.taille - 1)
				os << element.coeffs[i][element.taille - 1] << " } ,";
			else
				os << element.coeffs[i][element.taille - 1] << " }";

			if (i < element.taille - 1)
				os << std::endl;
		}
		os << "}" << std::endl;
		return os;
	};


	friend std::vector<T> operator*(std::vector<T> const& vec_ligne, matrice<T> const& m_matrice) {
		T faux = m_matrice.coeffs[0][0];
		faux = false;
		std::vector<T> resultat(m_matrice.taille, faux);
		for (int i(0); i < m_matrice.taille; ++i) {
			T somme = faux;
			for (int j(0); j < m_matrice.taille; ++j)
				somme = somme + (vec_ligne[j] * m_matrice.coeffs[j][i]);
			resultat[i] = somme;
		}

		return resultat;
	};

	friend std::vector<T> operator*(matrice<T> const& m_matrice, std::vector<T> const& vec_colonne) {
		T faux = m_matrice.coeffs[0][0];
		faux = false;
		std::vector<T> resultat(m_matrice.taille, faux);
		for (int i(0); i < m_matrice.taille; ++i) {
			T somme = faux;
			for (int j(0); j < m_matrice.taille; ++j)
				somme = somme + (m_matrice.coeffs[i][j] * vec_colonne[j]);
			resultat[i] = somme;
		}
		return resultat;
	};

	int taille;
	std::vector < std::vector< T>> coeffs;
};


template<class T> class matrice<T, typename std::enable_if_t<type_algebre<T>::type == 0>, typename std::enable_if_t<type_algebre<T>::approx == 1>> {
public:

	friend matrice<T> derivee(const matrice<T>& element) {
		matrice<T> result(element);
		for (int i(0); i < element.taille; ++i)
			for (int j(0); j < element.taille; ++j)
				result.coeffs[i][j] = derivee(result.coeffs[i][j]);
		return result;
	};

	explicit matrice(int m_taille, T element) : coeffs(m_taille, std::vector<T>(m_taille, element)), taille(m_taille) {
	};

	explicit matrice(int m_taille) : coeffs(m_taille, std::vector<T>(m_taille)), taille(m_taille) {
	};

	matrice(matrice<T> const& copie) {
		taille = copie.taille;
		coeffs = copie.coeffs;
	};

	explicit matrice(const std::vector<std::vector<T>>& vec) : coeffs(vec), taille(vec.size()) {
	};

	explicit matrice() : taille(0), coeffs(0, std::vector<T>(0)) {};

	explicit operator bool() const {
		for (int i(0); i < taille; ++i)
			for (int j(0); j < taille; ++j)
				if ((bool)coeffs[i][j])
					return true;
		return false;
	};

	template<class U> explicit operator matrice<U>() const {
		matrice<U> result;
		result.taille = taille;
		result.coeffs.resize(taille);
		for (int i(0); i < taille; ++i)
			result.coeffs[i].resize(taille);


		for (int i(0); i < taille; ++i)
			for (int j(0); j < taille; ++j)
				result.coeffs[i][j] = (U)coeffs[i][j];

		return result;
	};


	matrice<T>& operator=(bool test) {
		for (int i(0); i < taille; ++i)
			for (int j(0); j < taille; ++j)
				coeffs[i][j] = false;
		if (test)
			for (int i(0); i < taille; ++i)
				coeffs[i][i] = true;
		return *this;

	};

	template<class U> friend matrice<T> operator*(U scalaire, const matrice<T>& m_matrice) {
		matrice<T> result(m_matrice);
		for (int i(0); i < result.taille; ++i)
			for (int j(0); j < result.taille; ++j)
				result.coeffs[i][j] = scalaire * result.coeffs[i][j];
		return result;
	};

	/*
	friend matrice<T> operator%(const matrice<T>& temp1, const matrice<T>& temp2) {
		matrice<T> result = temp1;
		result = false;
		return result;
	};
	*/

	matrice<T> operator*(const matrice<T>& autre) const {
		T faux = coeffs[0][0];
		faux = false;

		if (taille != autre.taille)
			return matrice<T>(taille, faux);
		matrice<T> result(taille, faux);
		for (int i(0); i < taille; ++i)
			for (int j(0); j < taille; ++j) {
				T somme(faux);
				for (int k(0); k < taille; ++k)
					somme = somme + (coeffs[i][k] * autre.coeffs[k][j]);
				result.coeffs[i][j] = somme;
			}
		return result;
	};

	matrice<T> operator+(const matrice<T>& autre) const {
		T faux = coeffs[0][0];
		faux = false;

		if (taille != autre.taille)
			return matrice<T>(taille, faux);
		matrice<T> result(taille, faux);
		for (int i(0); i < taille; ++i)
			for (int j(0); j < taille; ++j)
				result.coeffs[i][j] = coeffs[i][j] + autre.coeffs[i][j];
		return result;
	};

	matrice<T> operator-(const matrice<T>& autre) const {
		T faux = coeffs[0][0];
		faux = false;
		if (taille != autre.taille)
			return matrice<T>(taille, faux);

		matrice<T> result(taille, faux);
		for (int i(0); i < taille; ++i)
			for (int j(0); j < taille; ++j)
				result.coeffs[i][j] = coeffs[i][j] - autre.coeffs[i][j];
		return result;
	};

	friend 	matrice<T> operator-(const matrice<T>& element) {
		T temp = element.coeffs[0][0];
		temp = false;
		matrice<T> result(element.taille, temp);
		for (int i(0); i < result.taille; ++i)
			for (int j(0); j < result.taille; ++j)
				result.coeffs[i][j] = -element.coeffs[i][j];
		return result;
	};

	T determinant_anneau() {
		T resultat = coeffs[0][0];
		resultat = false;
		T vrai = resultat;
		vrai = true;
		for (fact_for iter(taille); (bool)iter; ++iter) {
			T temp = vrai;
			for (int i(0); i < taille; ++i)
				temp = temp * coeffs[i][iter.permutation[i]];
			if (iter.signature < 0)
				temp = -temp;
			resultat = resultat + temp;
		}

		return resultat;
	};

	T determinant() const {
		matrice<T> m_matrice(*this);
		T det(coeffs[0][0]);
		det = true;
		T vrai = det;

		int taille_max = max(taille - 4, 0);
		int taille_fin = taille - taille_max;

		for (int i(0); i < taille_max; ++i) {
			int j_max = -1;
			auto norme_max = norme(vrai);
			for (int j = i; j < taille; ++j) {
				if ((bool) m_matrice.coeffs[i][j]) {
					auto norme_temp = norme(m_matrice.coeffs[i][j]);
					if (j_max == -1) {
						norme_max = norme_temp;
						j_max = j;
					}
					else
						if (norme_temp > norme_max) {
							norme_max = norme_temp;
							j_max = j;
						}
				}
			}
			if (j_max==-1)
				return (det = false);

			if (i != j_max) {
				m_matrice.echangerLigne(i, j_max);
				det = -det;
			}
			for (int j = i + 1; j < taille; ++j) {
				m_matrice.ajouterLigne(i, j, ((-m_matrice.coeffs[j][i]) / m_matrice.coeffs[i][i]));
			}

		}

		for (int i(0); i < taille_max; ++i)
			det = (det * m_matrice.coeffs[i][i]);

		if (taille_fin > 0) {
			matrice<T> m_matrice_fin(taille_fin);
			for(int i(0);i<taille_fin;++i)
				for (int j(0); j < taille_fin; ++j) 
					m_matrice_fin.coeffs[i][j] = m_matrice.coeffs[taille_max + i][taille_max + j];
			det = det * m_matrice_fin.determinant_anneau();
		}

		return det;
	};


	void echangerLigne(int i, int j) {
		if ((i < 0) || (i >= taille) || (j < 0) || (j >= taille))
			return;
		if (i == j)
			return;
		for (int k(0); k < taille; ++k) {
			T temp = coeffs[i][k];
			coeffs[i][k] = coeffs[j][k];
			coeffs[j][k] = temp;
		}
		return;
	};

	void ajouterLigne(int i, int j, T coefficient) { // ajouter ligne i * coeffs � la ligne j ...
		if ((i < 0) || (i >= taille) || (j < 0) || (j >= taille))
			return;
		if (i == j)
			return;
		for (int k(0); k < taille; ++k) {
			coeffs[j][k] = coeffs[j][k] + (coefficient * coeffs[i][k]);
		}
		return;
	};

	void multiplierLigne(int i, T coefficient) {
		for (int j(0); j < taille; ++j)
			coeffs[i][j] = coefficient * coeffs[i][j];
	};

	matrice<T> inverse() const {
		T vrai = coeffs[0][0];
		vrai = true;

		matrice<T> m_matrice(*this);
		matrice<T> resultat(taille, vrai);
		resultat = true; //identit�

		for (int i(0); i < taille; ++i) {
			int j_max = -1;
			auto norme_max = norme(vrai);
//			auto norme_max = norme_T<T>::norme(vrai);
			for (int j = i; j < taille; ++j) {
				if ((bool)m_matrice.coeffs[i][j]) {
					auto norme_temp = norme(m_matrice.coeffs[i][j]);
					if (j_max == -1) {
						norme_max = norme_temp;
						j_max = j;
					}
					else
						if (norme_temp > norme_max) {
							norme_max = norme_temp;
							j_max = j;
						}
				}
			}
			if (j_max == -1)
				throw std::domain_error("matrice non-inversible");

			if (i != j_max) {
				m_matrice.echangerLigne(i, j_max);
				resultat.echangerLigne(i, j_max);
			}
			resultat.multiplierLigne(i, vrai / m_matrice.coeffs[i][i]);
			m_matrice.multiplierLigne(i, vrai / m_matrice.coeffs[i][i]);

			for (int j = 0; j < taille; ++j) {
				if (j == i)
					continue;
				resultat.ajouterLigne(i, j, -m_matrice.coeffs[j][i]);
				m_matrice.ajouterLigne(i, j, -m_matrice.coeffs[j][i]);
			}
		}

		return resultat;
	};

	polynome<T> polynomeCaracteristique() const {
		T faux = coeffs[0][0];
		faux = false;

		T vrai = faux;
		vrai = true;

		T mvrai = vrai;
		mvrai = -mvrai;

		matrice<polynome<T>> m_matrice(taille, polynome<T>(faux));

		for (int i(0); i < taille; ++i)
			for (int j(0); j < taille; ++j)
				if (i != j)
					m_matrice.coeffs[i][j] = polynome<T>(coeffs[i][j]);
				else
					m_matrice.coeffs[i][j] = polynome<T>(coeffs[i][j], mvrai);

		auto det = m_matrice.determinant();

		return det;
	};

	friend std::ostream& operator<<(std::ostream& os, const matrice<T>& element) {
		os << "{ ";
		for (int i(0); i < element.taille; ++i) {
			os << "{ ";
			for (int j(0); j < element.taille - 1; ++j)
				os << element.coeffs[i][j] << " , ";
			if (i < element.taille - 1)
				os << element.coeffs[i][element.taille - 1] << " } ,";
			else
				os << element.coeffs[i][element.taille - 1] << " }";

			if (i < element.taille - 1)
				os << std::endl;
		}
		os << "}" << std::endl;
		return os;
	};


	friend std::vector<T> operator*(std::vector<T> const& vec_ligne, matrice<T> const& m_matrice) {
		T faux = m_matrice.coeffs[0][0];
		faux = false;
		std::vector<T> resultat(m_matrice.taille, faux);
		for (int i(0); i < m_matrice.taille; ++i) {
			T somme = faux;
			for (int j(0); j < m_matrice.taille; ++j)
				somme = somme + (vec_ligne[j] * m_matrice.coeffs[j][i]);
			resultat[i] = somme;
		}

		return resultat;
	};

	friend std::vector<T> operator*(matrice<T> const& m_matrice, std::vector<T> const& vec_colonne) {
		T faux = m_matrice.coeffs[0][0];
		faux = false;
		std::vector<T> resultat(m_matrice.taille, faux);
		for (int i(0); i < m_matrice.taille; ++i) {
			T somme = faux;
			for (int j(0); j < m_matrice.taille; ++j)
				somme = somme + (m_matrice.coeffs[i][j] * vec_colonne[j]);
			resultat[i] = somme;
		}
		return resultat;
	};

	int taille;
	std::vector < std::vector< T>> coeffs;
};



//template matrice<double>;

/*
template<class T> class matrice<T, typename std::enable_if<type_algebre<T>::type == 1>::type> : public matrice_base<T> {
public:
	using matrice_base<T>::coeffs;
	using matrice_base<T>::taille;

	explicit matrice() : taille(0), coeffs(0, std::vector<T>(0)) {
		std::cout << "copie";
	};

	explicit matrice(int m_taille, T element) : matrice<T>::coeffs(m_taille, std::vector<T>(m_taille, element)), matrice<T>::taille(m_taille) {
		std::cout << "copie";
	};

	virtual matrice<T>& operator=(matrice<T > const& copie) {
		taille = copie.taille;
		std::vector<std::vector<T>> coeffs = copie.coeffs;
		std::cout << "copie";
		return *this;
	};

	T determinant() const {
		matrice<rationnel<T>> m_matrice(taille);
		T vrai = coeffs[0][0];
		vrai = true;

		for (int i(0); i < taille; ++i)
			for (int j(0); j < taille; ++j)
				m_matrice.coeffs[i][j] = rationnel<T>(coeffs[i][j], vrai);

		rationnel<T> det = m_matrice.determinant();
		std::cout << "calcul determinant" << std::endl;

		return det.numerateur / det.denominateur;
	};

};

template<class T> class matrice<T, typename std::enable_if<type_algebre<T>::type == 0>::type> : public matrice_base<T> {
public:
	using matrice_base<T>::coeffs;
	using matrice_base<T>::taille;

};
*/

//template<class T> class matrice<T, typename std::enable_if<type_algebre<T>::type == 0, float>::type> : virtual public matrice<T, void> {
