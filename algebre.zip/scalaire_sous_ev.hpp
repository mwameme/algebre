#pragma once
#include <vector>

template<class T> class scalaire_sous_ev {



};