#pragma once

#include "polynome.hpp"
#include "rationnel.hpp"
#include "corps quotient.hpp"
#include "anneau quotient.hpp"
#include "InfInt.h"
#include "erreur.hpp"
#include "polynome_n.hpp"
#include "complexe.hpp"
#include "precision/fprecision.h"

#include "fonctions template.hpp"
#include "types.hpp"


template<class T> class type_algebre;

template<class T> class polynome_n;

//d�finition
template<class T, typename Enable=void> class norme_T {
public:
};

//classes de base :
template<> class norme_T<int> {
public:
	static int norme(int x) {
		return abs(x);
	};
};

template<> class norme_T<long> {
public:
	static long norme(long x) {
		return abs(x);
	};
};

template<> class norme_T<long long > {
public:
	static long long norme(long long x) {
		return abs(x);
	};
};

template<> class norme_T<int_precision> {
public:

	static int_precision norme(int_precision x) {
		return abs(x);
	};
};

template<> class norme_T<InfInt> {
public:
	static InfInt norme(InfInt x) {
		return abs(x);
	};
};

template<> class norme_T<float> {
public:
	static float norme(float x) {
		return abs(x);
	};
};

template<> class norme_T<double> {
public:
	static double norme(double x) {
		return abs(x);
	};
};

template<> class norme_T<float_precision> {
public:
	static float_precision norme(float_precision x) {
		return abs(x);
	};
};

template<class T> class norme_T<erreur<T>> {
public:
	static float norme(erreur<T> temp) {
		return norme_T<float>::norme((float) temp.valeur);
	};
};

//class compos�es
template<class T> class norme_T<complexe<T>> {
public:
	static decltype(norme_T<T>::norme(T())) norme(complexe<T> temp) {
		return norme_T<T>::norme(temp.x) + norme_T<T>::norme(temp.y);
	};
};

/*
template<class T> class norme_T< polynome<T> > {
public:
	static decltype(norme_T<T>::norme()) norme(polynome<T> poly) {
		decltype(norme_T<T>::norme()) x = norme_T<T>::norme(poly.coeffs[0]);
		for (int i(1); i < poly.coeffs.size(); ++i) {
			x = x + norme_T<T>::norme(poly.coeffs[i]);
		}
		return x;
	};
};*/

template<class T> class norme_T< polynome<T> > {
public:
	static decltype(norme_T<T>::norme(T())) norme(polynome<T> poly) {
		decltype(norme_T<T>::norme(T())) x = norme_T<T>::norme(poly.coeffs[0]);
		for (int i(1); i < poly.coeffs.size(); ++i) {
			x = x + norme_T<T>::norme(poly.coeffs[i]);
		}
		return x;
	};
};

template<class T> class norme_T< polynome_n<T> > {
public:
	static decltype(norme_T<T>::norme(T())) norme(polynome_n<T> poly) {
		if (poly.n_var >= 1) {
			decltype(norme_T<T>::norme(T())) x = norme_T<T>::norme(poly.element);
			x = false;
			for (int i(0); i < poly.coeffs.size(); ++i) {
				x = x + norme_T<polynome_n<T>>::norme(* poly.coeffs[i]);
			}
			return x;
		};
		return norme_T<T>::norme(poly.element);
	};
};


//deux cas : si norme(T) a une division exacte ou non.
template<class T> class norme_T < rationnel<T>, typename std::enable_if< type_algebre<decltype(norme_T<T>::norme(T()))>::type == 0 > ::type > {
public:
	static decltype(norme_T<T>::norme(T())) norme(rationnel<T> frac) {
//		decltype(norme_T<T>::norme()) x = norme_T<T>::norme(frac.numerateur) / norme_T<T>::norme(frac.denominateur);
		return norme_T<T>::norme(frac.numerateur) / norme_T<T>::norme(frac.denominateur);
	};

};

template<class T> class norme_T < rationnel<T>, typename std::enable_if< type_algebre<decltype(norme_T<T>::norme(T()))>::type != 0 > ::type > {
public:
	static rationnel<decltype(norme_T<T>::norme(T()))> norme(rationnel<T> frac) {
//		rationnel<decltype(norme_T<T>::norme())> x = rationnel<decltype(norme_T<T>::norme()) >> (norme_T<T>::norme(frac.numerateur), norme_T<T>::norme(frac.denominateur));
		auto x= rationnel<decltype(norme_T<T>::norme(T()))>(norme_T<T>::norme(frac.numerateur), norme_T<T>::norme(frac.denominateur));
		return x;
	};

};

template<class T> class norme_T < anneau_quotient<polynome<T>>> {
public:
	static decltype(norme_T<T>::norme(T())) norme(anneau_quotient<polynome<T>> x) {
		polynome<T> pgcd = PGCD(x.element, x.quotient); //dans cet ordre ... r�sultant proportionnel au coeff dominant de x.element.
		if (pgcd.degre >= 1) {
			T temp = pgcd.coeffs[0];
			temp = false;
			return norme_T<T>::norme(temp);
		}
		return norme_T<polynome<T>>::norme(pgcd);
	};
};


//pour aller plus vite : la fonction directement !
template<class T> inline decltype(norme_T<T>::norme(T())) norme(T x) {
	return norme_T<T>::norme(x);
};
