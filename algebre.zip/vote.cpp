#include "vote.hpp"
#include "TVD.hpp"

#include <vector>
using namespace std;

vector<double> vote(vector<vector<int>> const& votes, double epsilon_){
	int n = votes.size();
	vector<vector<int>> preferences(n, vector<int>(n, 0));

	for (int i(0); i < n; ++i) //on parcourt la liste de votes
		for (int j(0); j < n - 1; ++j)
			for (int k(j + 1); k < n; ++k) //on regarde j pr�f�r� � k
				preferences[votes[i][j]][votes[i][k]] += 1;

	vector<vector<double>> P(n, vector<double>(n, 0)); // matrice de transition
	double inv_n = 1. / ((double)n);
	double epsilon = epsilon_ * inv_n;
	double n_2 = (double)n / 2.;

	for (int i(0); i < n; ++i) // on parcourt la matrice de transitions
		for (int j(0); j < n; ++j)
			P[i][j] = inv_n * (1. + epsilon * (preferences[j][i] - n_2));

	double somme = 0; //calculer la stochasticit�
	for (int i(0); i < n; ++i) {
		double somme_temp = 0;
		for (int j(0); j < n; ++j)
			somme_temp += P[i][j];
		if (somme_temp > somme)
			somme = somme_temp;
	}

	double somme_inv = 1 / somme;
	for (int i(0); i < n; ++i)
		for (int j(0); j < n; ++j)
			P[i][j] = P[i][j] * somme_inv;

	//modifier les P_ii, toujours pour la stochasticit�
	for (int i(0); i < n; ++i) {
		somme = 0.;
		for (int j(0); j < n; ++j) {
			if (j == i)
				continue;
			somme += P[i][j];
		}
		P[i][i] = 1. - somme;
	}


	vector<double> X(n, inv_n); //calculer la proba stationnaire ...
	X = multiplication(X, puissance(P, 1024));

	somme = 0; //au cas o� X n'est pas strictement de masse 1.
	for (int i(0); i < n; +i)
		somme += X[i];
	somme_inv = 1. / somme;
	for (int i(0); i < n; ++i)
		X[i] *= somme_inv;

	//renvoyer le r�sultat ...
	vector<double> resultat(n, 0);
	double epsilon_inv = 1. / epsilon;
	for (int i(0); i < n; ++i)
		resultat[i] = (X[i] - inv_n) *epsilon_inv;

	return resultat;
}

vector<double> vote_iter(vector<vector<int>> const& votes, double epsilon,vector<double> const& poids) {
	int n = votes.size();
	vector<vector<double>> preferences(n, vector<double>(n, 0.));

	for (int i(0); i < n; ++i) //on parcourt la liste de votes
		for (int j(0); j < n - 1; ++j)
			for (int k(j + 1); k < n; ++k) //on regarde j pr�f�r� � k
				preferences[votes[i][j]][votes[i][k]] += poids[i]; //j pr�f�r� � k : de poids i.

	vector<vector<double>> P(n, vector<double>(n, 0)); // matrice de transition
	double inv_n = 1. / ((double)n);
//	double epsilon = epsilon_ * inv_n;

	for (int i(0); i < n; ++i) // on parcourt la matrice de transitions
		for (int j(0); j < n; ++j)
			P[i][j] = inv_n * (1 + epsilon * (preferences[j][i] - .5));

	double somme = 0; //calculer la stochasticit�
	for (int i(0); i < n; ++i) {
		double somme_temp = 0;
		for (int j(0); j < n; ++j)
			somme_temp += P[i][j];
		if (somme_temp > somme)
			somme = somme_temp;
	}

	double somme_inv = 1 / somme;
	for (int i(0); i < n; ++i)
		for (int j(0); j < n; ++j)
			P[i][j] = P[i][j] * somme_inv;

	//modifier les P_ii, toujours pour la stochasticit�
	for (int i(0); i < n; ++i) {
		somme = 0.;
		for (int j(0); j < n; ++j) {
			if (j == i)
				continue;
			somme += P[i][j];
		}
		P[i][i] = 1. - somme;
	}


	vector<double> X(n, inv_n); //calculer la proba stationnaire ...
	X = multiplication(X, puissance(P, 1024));

	somme = 0; //au cas o� X n'est pas strictement de masse 1. r�duit l'al�a (lors des it�rations)
	for (int i(0); i < n; +i)
		somme += X[i];
	somme_inv = 1. / somme;
	for (int i(0); i < n; ++i)
		X[i] *= somme_inv;

	//renvoyer le r�sultat ...

	return X;
}

vector<double> vote_n_iter(vector<vector<int>> const& votes, double epsilon,int iter) {
	int n = votes.size();
	vector<double> X(n, 1 / ((double)n));
	for (int i(0); i < iter; ++i)
		X = vote_iter(votes, epsilon, X);

	return X;
}